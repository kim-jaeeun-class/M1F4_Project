// 유저 정보 저장
const users = [
    { 
        name: '김하나',
        id: 'user01@naver.com',
        password: '1234',
        nickname: '안녕',
        interest: '스포츠',
        region: '충남',
        role: 'student',
        phone: '010-1111-2222'
    },
    {
        name: '홍길동',
        id: 'user02@gmail.com',
        password: '0000',
        role: 'volunteer',
        phone: '010-3333-4444'
    },
    {
        name: '고현지',
        id: 'tofhdns1130@naver.com',
        password: 'tofhdns',
        role: 'student',
        phone: '010-5555-6666'
    },
    {
        name: '윤성연',
        id: 'admin@gmail.com',
        password: 'admin',
        role: 'admin',
        phone: '010-0000-0000'
    }
];
